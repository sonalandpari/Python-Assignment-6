#Step-1 : Importing
from tkinter import *

#Step-2: GUI Interaction
window = Tk()
window.title = ("Calculator")
window.geometry('173x220')

#Step-3: Adding Inputs

e=Entry(window, width=25,borderwidth=10)
e.place(x=0, y=0)


# Numbers

def click(num):
    result = e.get()
    e.delete(0, END)
    e.insert(0,str(result)+ str(num))
    
b=Button(window, text = "1", width = 4, command=lambda:click(1))
b.place(x=5, y=100)

b=Button(window, text = "2", width = 4, command=lambda:click(2))
b.place(x=47, y=100)

b=Button(window, text = "3", width = 4, command=lambda:click(3))
b.place(x=89, y=100)

b=Button(window, text = "4", width = 4, command=lambda:click(4))
b.place(x=5, y=130)

b=Button(window, text = "5", width = 4, command=lambda:click(5))
b.place(x=47, y=130)

b=Button(window, text = "6", width = 4, command=lambda:click(6))
b.place(x=89, y=130)

b=Button(window, text = "7", width = 4, command=lambda:click(7))
b.place(x=5, y=160)

b=Button(window, text = "8", width = 4, command=lambda:click(8))
b.place(x=47, y=160)

b=Button(window, text = "9", width = 4, command=lambda:click(9))
b.place(x=89, y=160)

b=Button(window, text = "0", width = 4, command=lambda:click(0))
b.place(x=47, y=190)

def decimal():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,i/10)
    
b=Button(window, text = ".", width = 4,command= decimal)
b.place(x=89, y=190)


def backspace():
    n1 = e.get()
    e.delete(len(n1)-1,len(n1))

b=Button(window, text = "<-", width = 4,command= backspace)
b.place(x=131, y=40)



#Operators
def divide():
    n1 = e.get()
    global maths
    maths = "Division"
    global i
    i = int(n1)
    e.delete(0,END)

b=Button(window, text = "/", width = 4,command=divide)
b.place(x=131, y=70)


def Multiply():
    n1 = e.get()
    global maths
    maths = "multiply"
    global i
    i = int(n1)
    e.delete(0,END)

b=Button(window, text = "x", width = 4,command = Multiply)
b.place(x=131, y=100)


def Substract():
    n1 = e.get()
    global maths
    maths="Substraction"
    global i
    i = int(n1)
    e.delete(0,END)

b=Button(window, text = "-", width = 4,command = Substract)
b.place(x=131, y=130)


def Add():
    n1 = e.get()
    global maths
    maths = "Addition"
    global i
    i = int(n1)
    e.delete(0,END)

b=Button(window, text = "+", width = 4,command=Add)
b.place(x=131, y=160)


def Equal():
    n2 = e.get()
    global j
    j= int(n2)
    e.delete(0,END)
    if maths == "Addition" :
        e.insert(0, i+j)
    elif maths == "Substraction":
        e.insert(0,i-j)
    elif maths == "multiply":
        e.insert(0,i*j)
    elif maths == "Division":
         e.insert(0,i/j)

    
b=Button(window, text = "=", width = 4,command=Equal)
b.place(x=131, y=190)

def CE():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,i)                                                                                      #Please help me with this one it always delete the first input, I am unable to make it delete the second input (j)

b=Button(window, text = "CE", width = 4,command=CE)
b.place(x=47, y=40)

#Extras

def percentage():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,i/100)

b=Button(window, text = "%", width = 4, command=percentage)
b.place(x=5, y=40)

def clear_all():
      e.delete(0,END)

b=Button(window, text = "C", width = 4,command=clear_all)
b.place(x=89, y=40)

def reciprocal():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,1/i)


b=Button(window, text = "1/x", width = 4,command=reciprocal)
b.place(x=5, y=70)

def square():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,i*i)

b=Button(window, text = "x^2", width = 4, command=square)
b.place(x=47, y=70)


def root():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,i**0.5)

b=Button(window, text = "root", width = 4, command= root)
b.place(x=89, y=70)

def sign():
    n1 = e.get()
    global i
    i = int(n1)
    e.delete(0,END)
    e.insert(0,i* (-1))

b=Button(window, text = "+/-", width = 4, command= sign)
b.place(x=5, y=190)
     
#Step-4: Main loop
window.mainloop()